# User_Manual
User manual for Ant Forest  
  
##### _I'm trying to build it..._

下载项目 ([点此下载](https://codeload.github.com/SuperMonster003/Auto.js_Projects/zip/Ant_Forest))  
解压项目压缩包 并放置在设备本地存储中    
使用"Auto.js"运行"Ant_Forest_Launcher.js"即可